-- Tworzenie tabeli standardowych us�ug
CREATE TABLE [dbo].[uslugi]
(
    [idUslugi] INT IDENTITY(1,1) NOT NULL,
    [nazwaUslugi] VARCHAR(255) NOT NULL,
    [cena] DECIMAL(8,2) NOT NULL,
    PRIMARY KEY ([idUslugi])
);

-- Tworzenie tabeli sta�ych klient�w
CREATE TABLE [dbo].[staliKlienci]
(
    [idKlienta] INT IDENTITY(1,1) NOT NULL,
    [imie] VARCHAR(30) NOT NULL,
    [nazwisko] VARCHAR(50) NOT NULL,
    [nrTelefonu] VARCHAR(15) NOT NULL,
    PRIMARY KEY ([idKlienta])
);

-- Tworzenie tabeli um�wionych spotka�
CREATE TABLE [dbo].[umowioneSpotkania]
(
    [idSpotkania] INT IDENTITY(1,1) NOT NULL,
    [idKlienta] INT NOT NULL,
    [dataSpotkania] DATETIME NOT NULL,
    PRIMARY KEY ([idSpotkania]),
    FOREIGN KEY ([idKlienta]) REFERENCES [dbo].[staliKlienci] ([idKlienta]) ON UPDATE NO ACTION ON DELETE NO ACTION
);

-- Tabela informacji o wykonanych us�ugach dla sta�ych klient�w
CREATE TABLE [dbo].[wykonaneUslugi]
(
    [idWykonanejUslugi] INT IDENTITY(1,1) NOT NULL,
    [idKlienta] INT NOT NULL,
    [idUslugi] INT NOT NULL,
    [dataWykonania] DATETIME NOT NULL,
    PRIMARY KEY ([idWykonanejUslugi]),
    FOREIGN KEY ([idKlienta]) REFERENCES [dbo].[staliKlienci] ([idKlienta]) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY ([idUslugi]) REFERENCES [dbo].[uslugi] ([idUslugi]) ON UPDATE NO ACTION ON DELETE NO ACTION
);

-- Tabela rabat�w przyznanych sta�ym klientom na pewne ustalone us�ugi
CREATE TABLE [dbo].[rabatyStalymKlientom]
(
    [idRabatu] INT IDENTITY(1,1) NOT NULL,
    [idKlienta] INT NOT NULL,
    [idUslugi] INT NOT NULL,
    [procentRabatu] DECIMAL(4,2) NOT NULL,
    PRIMARY KEY ([idRabatu]),
    FOREIGN KEY ([idKlienta]) REFERENCES [dbo].[staliKlienci] ([idKlienta]) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY ([idUslugi]) REFERENCES [dbo].[uslugi] ([idUslugi]) ON UPDATE NO ACTION ON DELETE NO ACTION
);

-- Tabela rabat�w przyznanych klientom na wszystkie us�ugi
CREATE TABLE [dbo].[rabatyNaWszystko]
(
    [idRabatu] INT IDENTITY(1,1) NOT NULL,
    [idKlienta] INT NOT NULL,
    [procentRabatu] DECIMAL(4,2) NOT NULL,
    PRIMARY KEY ([idRabatu]),
    FOREIGN KEY ([idKlienta]) REFERENCES [dbo].[staliKlienci] ([idKlienta]) ON UPDATE NO ACTION ON DELETE NO ACTION
);

-- Tabela rabat�w stosowanych w przypadku kompleksowych us�ug
CREATE TABLE [dbo].[rabatyKompleksowe]
(
    [idRabatu] INT IDENTITY(1,1) NOT NULL,
    [idUslugiKompleksowej] INT NOT NULL,
    [procentRabatu] DECIMAL(4,2) NOT NULL,
    PRIMARY KEY ([idRabatu]),
    FOREIGN KEY ([idUslugiKompleksowej]) REFERENCES [dbo].[uslugi] ([idUslugi]) ON UPDATE NO ACTION ON DELETE NO ACTION
);
